//getMoves()
//Crear una función getMoves que tome como argumento un pokémon y devuelva la lista de movimientos

const pikachu = getPikachu();
const spreadPikachu = {
    ...pikachu.name,
    ...pikachu.type,
    ability: {...pikachu.ability},
    stats: {...pikachu.stats},
    moves: [...pikachu.moves],
    modifiers: {weakness: [...pikachu.modifiers.weakness],
    resistances: [...pikachu.modifiers.resistances]
    }
}
const{name, type, ability:{primary, hidden}, stats:{hp, attack, deffense, spead}, moves, modifiers:{weakness, resistances}} = spreadPikachu;

const getMoves = (pokemon) =>moves
console.log(getMoves(spreadPikachu))

//getPrimaryAbility()
// Crear una función getPrimaryAbility que tome como argumento un pokémon y devuelva la habilidad primaria

const getPrimaryAbility = (pokemon) => primary;
console.log(getPrimaryAbility(spreadPikachu))

// getWeaknesses()
// Crear una función getWeaknesses que tome como argumento un pokémon y devuelva la lista de tipos contra los que es débil
const getWeaknesses = pokemon =>weakness;
console.log(getWeaknesses(spreadPikachu));

// getResistances()
// Crear una función getResistances que tome como argumento un pokémon y devuelva la lista de tipos contra los que es débil

const getResistances = pokemon => resistances;
console.log(getResistances(spreadPikachu));



// Crear una función resistsType que tome como argumentos un pokémon y un tipo y devuelva true si el pokémon es resistente a dicho tipo

const resistsType = (pokemon, type) =>{
    if (resistances.includes(type)){
        return true
    } else{
        return false
    }

}
console.log(resistsType(spreadPikachu, "electric"))